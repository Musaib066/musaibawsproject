name="Amrita"
age=20
salary=30000
print("My name is ",name, "My age is",age, "My salary is",salary)
name="Anvi"
age= 8
salary=20000
print("My daugther name is",name "Her age is",age)

