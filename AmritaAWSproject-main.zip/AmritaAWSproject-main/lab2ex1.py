myvalue=1
print(myvalue)
print(type(myvalue))
print( str(myvalue) + " is of the data type " + str(type(myvalue)))
myvalue=3.14
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
myvalue=5j
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
myValue=True
print(myValue)
print(type(myValue))
print(str(myValue) + "is of the data type" + str(type(myValue)))
myValue=False
print(myValue)
print(type(myvalue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

